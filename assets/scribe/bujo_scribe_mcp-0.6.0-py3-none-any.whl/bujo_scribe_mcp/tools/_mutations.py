"""Per-op mutation helpers — apply a single decision to a ParsedNote in place.

Each function returns a list of `DiffAdded|DiffChanged|DiffRemoved|DiffMoved`
entries describing what changed. Mutations that can't apply (bullet not
found, ambiguous match, constraint failure) return a string reason code
instead — the caller routes it into `unmatched`.

Cross-note effects (migrate, schedule) return side-effect instructions as
well, which the orchestrator resolves against other notes.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta

from bujo_scribe_mcp.parsing import BlankLine, BujoLine, ParsedNote, UnrecognizedLine
from bujo_scribe_mcp.parsing.renderer import render_line
from bujo_scribe_mcp.rules import Rules
from bujo_scribe_mcp.schemas import (
    Bullet,
    DecisionAdd,
    DecisionCombine,
    DecisionComplete,
    DecisionDrop,
    DecisionMigrate,
    DecisionRemove,
    DecisionReorder,
    DecisionSchedule,
    DecisionUndrop,
    DecisionUpdate,
    DiffAdded,
    DiffChanged,
    DiffMoved,
    DiffRemoved,
)
from bujo_scribe_mcp.tools._matching import find_matches


# ---------------------------------------------------------------------------
# Side-effect request passed back to orchestrator
# ---------------------------------------------------------------------------


@dataclass
class CrossNoteRequest:
    """The mutation wants another note modified, too.

    If `after_anchor` is None, lines are appended at the end. Otherwise,
    the handler finds the matching parent line on the target note and
    inserts immediately after it; if the parent can't be found, the
    request fails (see apply_decisions._apply_cross_note)."""

    target_slug: str  # resolver slug or explicit title
    lines_to_append: list[BujoLine]
    after_anchor: str | None = None
    require_target_exists: bool = False


# ---------------------------------------------------------------------------
# Matching helper — returns (BujoLine | reason-code)
# ---------------------------------------------------------------------------


def _resolve_target(note: ParsedNote, bullet_text: str) -> BujoLine | str:
    """Return the matched line, or an error reason code."""
    matches = find_matches(note, bullet_text)
    if not matches:
        return "NOT_FOUND"
    if len(matches) > 1:
        return "AMBIGUOUS_BULLET"
    return matches[0]


# ---------------------------------------------------------------------------
# Op implementations
# ---------------------------------------------------------------------------


def apply_complete(
    note: ParsedNote,
    decision: DecisionComplete,
    rules: Rules,
) -> tuple[list, str | None]:
    target = _resolve_target(note, decision.bullet)
    if isinstance(target, str):
        return ([], target)

    before_html = render_line(target, rules)
    target.signifier = "completed"
    target.anchor = target.anchor  # unchanged; completion preserves text
    after_html = render_line(target, rules)

    return (
        [DiffChanged(before=before_html, after=after_html)],
        None,
    )


def apply_drop(
    note: ParsedNote,
    decision: DecisionDrop,
    rules: Rules,
) -> tuple[list, str | None]:
    target = _resolve_target(note, decision.bullet)
    if isinstance(target, str):
        return ([], target)

    before_html = render_line(target, rules)
    target.dropped = True
    after_html = render_line(target, rules)

    return (
        [DiffChanged(before=before_html, after=after_html)],
        None,
    )


def apply_undrop(
    note: ParsedNote,
    decision: DecisionUndrop,
    rules: Rules,
) -> tuple[list, str | None]:
    target = _resolve_target(note, decision.bullet)
    if isinstance(target, str):
        return ([], target)

    if not target.dropped:
        return ([], "NOT_DROPPED")

    before_html = render_line(target, rules)
    target.dropped = False
    after_html = render_line(target, rules)

    return (
        [DiffChanged(before=before_html, after=after_html)],
        None,
    )


def apply_update(
    note: ParsedNote,
    decision: DecisionUpdate,
    rules: Rules,
) -> tuple[list, str | None]:
    target = _resolve_target(note, decision.bullet)
    if isinstance(target, str):
        return ([], target)

    before_html = render_line(target, rules)
    target.text = decision.new_text
    after_html = render_line(target, rules)

    return (
        [DiffChanged(before=before_html, after=after_html)],
        None,
    )


def apply_add(
    note: ParsedNote,
    decision: DecisionAdd,
    rules: Rules,
) -> tuple[list, str | None]:
    bullet: Bullet = decision.bullet
    new_line = BujoLine(
        signifier=bullet.signifier,
        text=bullet.text,
        prefix=_prefix_key(bullet),
        anchor=bullet.text[:60],
    )
    note.lines.append(new_line)
    return (
        [DiffAdded(section=decision.section, bullet=render_line(new_line, rules))],
        None,
    )


def apply_remove(
    note: ParsedNote,
    decision: DecisionRemove,
    rules: Rules,
) -> tuple[list, str | None]:
    """Remove a line from the note — works across BujoLine AND UnrecognizedLine.

    Matching rule (case-sensitive substring):
    - BujoLine: exact text match OR anchor match OR substring of text
    - UnrecognizedLine: substring match against the raw_html's text content
    - BlankLine: never matches

    Ambiguity rules: if >1 line matches, return AMBIGUOUS_BULLET without
    mutating. If 0 match, return NOT_FOUND.
    """
    needle = decision.bullet.strip()
    if not needle:
        return ([], "NOT_FOUND")

    # Collect (index, rendered-representation) pairs for matches.
    matches: list[tuple[int, str]] = []
    for idx, line in enumerate(note.lines):
        if isinstance(line, BujoLine):
            if line.text == needle or line.anchor == needle or needle in line.text:
                matches.append((idx, render_line(line, rules)))
        elif isinstance(line, UnrecognizedLine):
            # Strip tags from raw_html for a best-effort text match.
            import html as _html
            import re as _re

            unwrapped = _re.sub(r"<[^>]+>", "", _html.unescape(line.raw_html)).strip()
            if needle in unwrapped:
                matches.append((idx, line.raw_html))

    if not matches:
        return ([], "NOT_FOUND")
    if len(matches) > 1:
        return ([], "AMBIGUOUS_BULLET")

    idx, rendered = matches[0]
    del note.lines[idx]
    return ([DiffRemoved(bullet=rendered)], None)


def apply_reorder(
    note: ParsedNote,
    decision: DecisionReorder,
    rules: Rules,
) -> tuple[list, str | None]:
    # For single-block tier notes (Gap 5), "section" is advisory — we reorder
    # matching BujoLines globally in the given order. Non-BujoLines (blanks,
    # unrecognized) keep their relative position.

    bujo_indices = [i for i, line in enumerate(note.lines) if isinstance(line, BujoLine)]
    bujo_lines = [note.lines[i] for i in bujo_indices]

    # Build ordered matches by text prefix.
    new_order: list[BujoLine] = []
    used_ids = set()
    for needle in decision.order:
        for line in bujo_lines:
            if id(line) in used_ids:
                continue
            if needle.strip() in line.text:
                new_order.append(line)
                used_ids.add(id(line))
                break

    # Any unmentioned bullets keep their relative order at the end.
    for line in bujo_lines:
        if id(line) not in used_ids:
            new_order.append(line)

    # Re-slot into note.lines.
    moves: list = []
    for slot, line in zip(bujo_indices, new_order, strict=True):
        if note.lines[slot] is not line:
            moves.append(DiffMoved(**{"from": "bujo", "to": "bujo", "bullet": render_line(line, rules)}))
        note.lines[slot] = line

    return (moves, None)


def apply_migrate(
    note: ParsedNote,
    decision: DecisionMigrate,
    rules: Rules,
) -> tuple[list, str | None, CrossNoteRequest | None]:
    target = _resolve_target(note, decision.bullet)
    if isinstance(target, str):
        return ([], target, None)

    # Snapshot original for the target note (re-emit as an open task by default).
    carry = BujoLine(
        signifier=target.signifier if target.signifier != "migrated" else "task",
        text=target.text,
        prefix=target.prefix,
        depth=target.depth,
        anchor=target.anchor,
    )

    before_html = render_line(target, rules)
    target.signifier = "migrated"
    after_html = render_line(target, rules)

    diffs = [
        DiffChanged(before=before_html, after=after_html),
        DiffMoved(**{"from": note.title, "to": decision.target, "bullet": render_line(carry, rules)}),
    ]
    return (diffs, None, CrossNoteRequest(target_slug=decision.target, lines_to_append=[carry]))


def apply_combine(
    note: ParsedNote,
    decision: DecisionCombine,
    rules: Rules,
) -> tuple[list, str | None, CrossNoteRequest | None]:
    """Combine a source bullet into a parent on another note as a sub-item.

    Source: signifier → `migrated` (same visual effect as a regular migrate).
    Target: a new `sub_item` line (depth=1) is inserted right after the
    matching `parent_bullet`, carrying the source text + prefix.

    Parent-validation happens in the cross-note handler; if the parent
    can't be found on the target, the cross-note handler raises
    CombineTargetError and apply_decisions rolls back the source mutation.
    """
    target = _resolve_target(note, decision.bullet)
    if isinstance(target, str):
        return ([], target, None)

    carry = BujoLine(
        signifier="sub_item",
        text=target.text,
        prefix=target.prefix,
        depth=1,
        anchor=target.text[:60],
    )

    before_html = render_line(target, rules)
    target.signifier = "migrated"
    after_html = render_line(target, rules)

    diffs = [
        DiffChanged(before=before_html, after=after_html),
        DiffMoved(
            **{
                "from": note.title,
                "to": decision.target_note,
                "bullet": render_line(carry, rules),
            }
        ),
    ]
    return (
        diffs,
        None,
        CrossNoteRequest(
            target_slug=decision.target_note,
            lines_to_append=[carry],
            after_anchor=decision.parent_bullet,
            require_target_exists=True,
        ),
    )


def apply_schedule(
    note: ParsedNote,
    decision: DecisionSchedule,
    rules: Rules,
    *,
    today: date,
    future_log_slug: str = "future_log",
) -> tuple[list, str | None, CrossNoteRequest | None]:
    # Gap 2 guard — future date required.
    try:
        scheduled_date = date.fromisoformat(decision.date)
    except ValueError:
        return ([], "SCHEDULE_NEEDS_FUTURE_DATE", None)

    if scheduled_date <= today:
        return ([], "SCHEDULE_NEEDS_FUTURE_DATE", None)

    target = _resolve_target(note, decision.bullet)
    if isinstance(target, str):
        return ([], target, None)

    # Original line on the daily gets `<` signifier.
    before_html = render_line(target, rules)
    target.signifier = "scheduled"
    after_html = render_line(target, rules)

    # Future Log entry: scheduled event with the date + provenance.
    fl_line = BujoLine(
        signifier="scheduled",
        text=f"[{decision.date}] {target.text}  (from {note.title})",
        anchor=f"[{decision.date}] {target.text}"[:60],
    )

    diffs = [
        DiffChanged(before=before_html, after=after_html),
        DiffMoved(**{"from": note.title, "to": future_log_slug, "bullet": render_line(fl_line, rules)}),
    ]
    return (diffs, None, CrossNoteRequest(target_slug=future_log_slug, lines_to_append=[fl_line]))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _prefix_key(bullet: Bullet):
    """Return the internal prefix key for a Bullet, or None."""
    return bullet.prefix


# ---------------------------------------------------------------------------
# Scaffold helper — build a fresh ParsedNote from Section input
# ---------------------------------------------------------------------------


def build_scaffold_lines(sections, rules: Rules, setup_time: bool) -> list[BujoLine | BlankLine]:
    """Build the line sequence for a scaffold.

    `setup_time=True` triggers Gap-rule ordering: events → tasks → notes,
    regardless of the order sections were provided in.
    Otherwise preserves section order and bullet order exactly.
    """
    all_bullets: list[tuple[str, Bullet]] = []
    for section in sections:
        for bullet in section.bullets:
            all_bullets.append((section.name, bullet))

    if setup_time and rules.entry_style.setup_time_ordering.enabled:
        order = rules.entry_style.setup_time_ordering.order
        bucket_of = _sig_to_bucket(rules)
        bucket_position = {bucket: i for i, bucket in enumerate(order)}
        indexed = list(enumerate(all_bullets))
        indexed.sort(
            key=lambda pair: (
                bucket_position.get(bucket_of.get(pair[1][1].signifier, "tasks"), 999),
                pair[0],
            )
        )
        all_bullets = [b for _, b in indexed]

    lines: list[BujoLine | BlankLine] = []
    for _, bullet in all_bullets:
        lines.append(
            BujoLine(
                signifier=bullet.signifier,
                text=bullet.text,
                prefix=_prefix_key(bullet),
                anchor=bullet.text[:60],
            )
        )
    return lines


def _sig_to_bucket(rules: Rules) -> dict[str, str]:
    """Map signifier keys → setup-time-ordering bucket names (events/tasks/notes).

    Built-in keys are hardcoded; extensions contribute their `class` field.
    Unknown keys default to `tasks` (callers that pass an unknown signifier
    see it sorted with tasks, which is the least-surprising default).
    """
    bucket: dict[str, str] = {
        "task": "tasks",
        "event": "events",
        "note": "notes",
        "completed": "tasks",
        "migrated": "tasks",
        "scheduled": "tasks",
        "sub_item": "notes",
    }
    # `class` is "task" | "event" | "note" — map to "tasks" / "events" / "notes" bucket.
    for ext in rules.signifiers.extensions:
        bucket[ext.key] = f"{ext.class_}s"
    return bucket
