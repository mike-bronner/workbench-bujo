"""Pydantic schemas for every scribe verb.

These are the authoritative input/output shapes — they mirror
`docs/scribe-contract.md` in workbench-bujo. Changing anything here is a
contract change; bump the package version and update dependents.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Shared types
# ---------------------------------------------------------------------------

# `Signifier` is intentionally a free-form string. Built-in keys — task,
# event, note, research — are recognized by every backend. Additional keys
# are validated at the verb-execution layer against
# `rules.signifiers.extensions`. A Literal here would prevent user-defined
# extensions from crossing the MCP boundary.
Signifier = str
# `Prefix` is a prefix-key string — built-ins are "priority", "inspiration",
# "explore"; users may add more via `rules.signifiers.prefix_extensions`.
Prefix = str
Ritual = Literal["daily", "weekly", "monthly", "yearly"]


class Bullet(BaseModel):
    signifier: Signifier
    text: str
    prefix: Prefix | None = Field(
        default=None,
        description=(
            "Optional prefix signifier — a built-in key "
            "(priority | inspiration | explore) or a user-defined key from "
            "rules.signifiers.prefix_extensions."
        ),
    )
    owner: str | None = Field(default=None, description="Owner, e.g. for family-calendar items.")
    source: str | None = Field(default=None, description="Provenance string the scribe may note inline.")


class Section(BaseModel):
    name: str
    bullets: list[Bullet] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Diff format (shared across mutation verbs)
# ---------------------------------------------------------------------------

class DiffAdded(BaseModel):
    section: str
    bullet: str


class DiffChanged(BaseModel):
    before: str
    after: str


class DiffRemoved(BaseModel):
    bullet: str


class DiffMoved(BaseModel):
    from_: str = Field(alias="from")
    to: str
    bullet: str

    model_config = {"populate_by_name": True}


class Diff(BaseModel):
    added: list[DiffAdded] = Field(default_factory=list)
    changed: list[DiffChanged] = Field(default_factory=list)
    removed: list[DiffRemoved] = Field(default_factory=list)
    moved: list[DiffMoved] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

ErrorCode = Literal[
    "INDEX_MISSING",
    "FOLDER_MISSING",
    "NOTE_NOT_FOUND",
    "RULE_VIOLATION",
    "AMBIGUOUS_BULLET",
    "NOT_FOUND",
    "STALE_WRITE_DETECTED",
    "BACKEND_ERROR",
]


class ScribeError(BaseModel):
    code: ErrorCode
    detail: str
    context: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Verb: read
# ---------------------------------------------------------------------------

class ReadInput(BaseModel):
    notes: list[str] = Field(description="Canonical slugs or explicit note titles.")


class NoteContent(BaseModel):
    title: str
    exists: bool
    content: str | None
    retrieved_at: str


class ReadOutput(BaseModel):
    packet: dict[str, NoteContent]


# ---------------------------------------------------------------------------
# Verb: scaffold
# ---------------------------------------------------------------------------

class ScaffoldInput(BaseModel):
    target: str
    ritual: Ritual
    mode: Literal["create", "merge"]
    sections: list[Section] = Field(default_factory=list)


class ScaffoldWarning(BaseModel):
    code: ErrorCode
    bullet: str
    detail: str


class ScaffoldOutput(BaseModel):
    note_id: str
    created: bool
    diff: Diff
    warnings: list[ScaffoldWarning] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Verb: apply-decisions
# ---------------------------------------------------------------------------

class DecisionComplete(BaseModel):
    op: Literal["complete"]
    bullet: str


class DecisionMigrate(BaseModel):
    op: Literal["migrate"]
    bullet: str
    target: str


class DecisionSchedule(BaseModel):
    op: Literal["schedule"]
    bullet: str
    date: str  # YYYY-MM-DD


class DecisionDrop(BaseModel):
    op: Literal["drop"]
    bullet: str


class DecisionAdd(BaseModel):
    op: Literal["add"]
    section: str
    bullet: Bullet


class DecisionUpdate(BaseModel):
    op: Literal["update"]
    bullet: str
    new_text: str


class DecisionReorder(BaseModel):
    op: Literal["reorder"]
    section: str
    order: list[str]


class DecisionRemove(BaseModel):
    """Delete a line from a note entirely — matching across BuJo lines AND
    UnrecognizedLines. Unlike `drop` (which strike-throughs a BuJo task),
    `remove` fully deletes. Use to clean malformed/legacy content that
    predates the scribe."""

    op: Literal["remove"]
    bullet: str


Decision = (
    DecisionComplete
    | DecisionMigrate
    | DecisionSchedule
    | DecisionDrop
    | DecisionAdd
    | DecisionUpdate
    | DecisionReorder
    | DecisionRemove
)


class ApplyDecisionsInput(BaseModel):
    note: str
    decisions: list[Decision]
    dry_run: bool = Field(default=False, description="Compute diff without writing.")


class UnmatchedDecision(BaseModel):
    decision: dict[str, Any]
    reason: str


class CrossNoteEffect(BaseModel):
    note: str
    diff: Diff


class ApplyDecisionsOutput(BaseModel):
    note_id: str
    diff: Diff
    unmatched: list[UnmatchedDecision] = Field(default_factory=list)
    cross_note_effects: list[CrossNoteEffect] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Verb: scan
# ---------------------------------------------------------------------------

class ScanFilter(BaseModel):
    status: Literal["open", "due_today", "overdue", "surfaces_today"] | None = None
    type: Literal["task", "event", "note"] | None = None
    date: str | None = None  # YYYY-MM-DD, defaults to today


class ScanInput(BaseModel):
    scope: list[str]
    filter: ScanFilter = Field(default_factory=ScanFilter)


class ScanItem(BaseModel):
    note: str
    section: str
    signifier: Signifier
    text: str
    anchor: str
    due: str | None = None


class ScanOutput(BaseModel):
    items: list[ScanItem]


# ---------------------------------------------------------------------------
# Verb: summarize
# ---------------------------------------------------------------------------

SummaryKind = Literal["daily_morning", "weekly_retro", "monthly_retro", "yearly_retro"]


class SummarizeInput(BaseModel):
    kind: SummaryKind
    packet: dict[str, Any]
    format: Literal["display", "note"]


class SummarizeOutput(BaseModel):
    block: str
    stats: dict[str, Any] = Field(default_factory=dict)
